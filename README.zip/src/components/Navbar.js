import React from 'react';
import { Link } from 'react-router-dom';
import './Navbar.css';

const Navbar = () => {
  return (
    <nav className="navbar">
      <div className="nav-container">
        <Link to="/" className="nav-logo">
          <h2>Dravid X1 Sports</h2>
        </Link>
        <ul className="nav-menu">
          <li className="nav-item">
            <Link to="/" className="nav-link">Home</Link>
          </li>
          <li className="nav-item">
            <Link to="/booking" className="nav-link">Book Turf</Link>
          </li>
          <li className="nav-item">
            <Link to="/owner/login" className="nav-link">Owner Login</Link>
          </li>
        </ul>
      </div>
    </nav>
  );
};

export default Navbar;
