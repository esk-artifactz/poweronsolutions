import React from 'react';
import { Link } from 'react-router-dom';
import './TurfList.css';

const TurfList = () => {
  const turfs = [
    {
      id: 1,
      name: 'Football Turf A',
      type: 'Football',
      price: 800,
      image: '/football-turf.jpg',
      features: ['FIFA Approved', 'Flood Lights', 'Changing Room']
    },
    {
      id: 2,
      name: 'Cricket Ground',
      type: 'Cricket',
      price: 1200,
      image: '/cricket-ground.jpg',
      features: ['Pitch Perfect', 'Nets', 'Pavilion']
    },
    {
      id: 3,
      name: 'Badminton Court 1',
      type: 'Badminton',
      price: 400,
      image: '/badminton-court.jpg',
      features: ['Wooden Floor', 'LED Lights', 'Seating Area']
    },
    {
      id: 4,
      name: 'Tennis Court',
      type: 'Tennis',
      price: 600,
      image: '/tennis-court.jpg',
      features: ['Hard Court', 'Flood Lights', 'Practice Wall']
    }
  ];

  return (
    <div className="turf-list-container">
      <div className="hero-section">
        <h1>Dravid X1 Sports Club</h1>
        <p>Book premium sports facilities</p>
      </div>

      <div className="turf-grid">
        {turfs.map(turf => (
          <div key={turf.id} className="turf-card">
            <div className="turf-image">
              <img src={turf.image} alt={turf.name} />
              <div className="turf-type">{turf.type}</div>
            </div>
            <div className="turf-info">
              <h3>{turf.name}</h3>
              <div className="turf-features">
                {turf.features.map((feature, index) => (
                  <span key={index} className="feature-tag">{feature}</span>
                ))}
              </div>
              <div className="turf-footer">
                <div className="price">₹{turf.price}/hour</div>
                <Link to="/booking" className="book-btn">Book Now</Link>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TurfList;
