import React, { useState } from 'react';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import moment from 'moment';
import './Dashboard.css';

const Dashboard = ({ user, onLogout }) => {
  const [activeTab, setActiveTab] = useState('create-booking');
  const [bookings, setBookings] = useState([
    {
      id: 1,
      customerName: 'John Doe',
      email: 'john@example.com',
      phone: '9876543210',
      turfType: 'Football',
      date: '2024-04-06',
      startTime: '09:00',
      endTime: '11:00',
      status: 'confirmed',
      specialRequests: 'Need extra water bottles',
      createdAt: '2024-04-05T10:30:00Z'
    },
    {
      id: 2,
      customerName: 'Jane Smith',
      email: 'jane@example.com',
      phone: '9876543211',
      turfType: 'Cricket',
      date: '2024-04-07',
      startTime: '14:00',
      endTime: '17:00',
      status: 'confirmed',
      specialRequests: '',
      createdAt: '2024-04-05T11:15:00Z'
    },
    {
      id: 3,
      customerName: 'Mike Johnson',
      email: 'mike@example.com',
      phone: '9876543212',
      turfType: 'Badminton',
      date: '2024-04-05',
      startTime: '18:00',
      endTime: '20:00',
      status: 'cancelled',
      specialRequests: 'Evening slot preferred',
      createdAt: '2024-04-05T09:00:00Z'
    }
  ]);

  const [bookingForm, setBookingForm] = useState({
    customerName: '',
    email: '',
    phone: '',
    turfType: 'football',
    date: new Date(),
    startTime: '',
    endTime: '',
    specialRequests: ''
  });

  const turfTypes = [
    { value: 'football', label: 'Football Turf', price: 800 },
    { value: 'cricket', label: 'Cricket Ground', price: 1200 },
    { value: 'badminton', label: 'Badminton Court', price: 400 },
    { value: 'tennis', label: 'Tennis Court', price: 600 }
  ];

  const timeSlots = [
    '06:00', '07:00', '08:00', '09:00', '10:00', '11:00',
    '12:00', '13:00', '14:00', '15:00', '16:00', '17:00',
    '18:00', '19:00', '20:00', '21:00', '22:00'
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'confirmed': return '#28a745';
      case 'pending': return '#ffc107';
      case 'cancelled': return '#dc3545';
      default: return '#6c757d';
    }
  };

  const handleBookingFormChange = (e) => {
    setBookingForm({
      ...bookingForm,
      [e.target.name]: e.target.value
    });
  };

  const handleDateChange = (date) => {
    setBookingForm({
      ...bookingForm,
      date
    });
  };

  const handleCreateBooking = (e) => {
    e.preventDefault();
    
    const newBooking = {
      id: bookings.length + 1,
      ...bookingForm,
      date: moment(bookingForm.date).format('YYYY-MM-DD'),
      status: 'confirmed',
      createdAt: new Date().toISOString()
    };

    setBookings([newBooking, ...bookings]);
    
    // Reset form
    setBookingForm({
      customerName: '',
      email: '',
      phone: '',
      turfType: 'football',
      date: new Date(),
      startTime: '',
      endTime: '',
      specialRequests: ''
    });
    
    alert('Booking created successfully!');
  };

  const handleStatusUpdate = (bookingId, newStatus) => {
    setBookings(bookings.map(booking => 
      booking.id === bookingId ? { ...booking, status: newStatus } : booking
    ));
  };

  const calculatePrice = () => {
    const turf = turfTypes.find(t => t.value === bookingForm.turfType);
    if (!turf || !bookingForm.startTime || !bookingForm.endTime) return 0;
    
    const start = parseInt(bookingForm.startTime.split(':')[0]);
    const end = parseInt(bookingForm.endTime.split(':')[0]);
    const hours = end - start;
    
    return turf.price * hours;
  };

  return (
    <div className="dashboard-container">
      <div className="dashboard-header">
        <div className="header-content">
          <h1>Owner Dashboard</h1>
          <div className="user-info">
            <span>Welcome, {user.email}</span>
            <button onClick={onLogout} className="logout-btn">Logout</button>
          </div>
        </div>
      </div>

      <div className="dashboard-content">
        <div className="sidebar">
          <div className="nav-item">
            <button 
              className={activeTab === 'create-booking' ? 'active' : ''}
              onClick={() => setActiveTab('create-booking')}
            >
              ➕ Create Booking
            </button>
          </div>
          <div className="nav-item">
            <button 
              className={activeTab === 'bookings' ? 'active' : ''}
              onClick={() => setActiveTab('bookings')}
            >
              📅 View Bookings
            </button>
          </div>
          <div className="nav-item">
            <button 
              className={activeTab === 'analytics' ? 'active' : ''}
              onClick={() => setActiveTab('analytics')}
            >
              📊 Analytics
            </button>
          </div>
        </div>

        <div className="main-content">
          {activeTab === 'create-booking' && (
            <div className="create-booking-section">
              <h2>Create New Booking</h2>
              <form onSubmit={handleCreateBooking} className="booking-form">
                <div className="form-row">
                  <div className="form-group">
                    <label htmlFor="customerName">Customer Name</label>
                    <input
                      type="text"
                      id="customerName"
                      name="customerName"
                      value={bookingForm.customerName}
                      onChange={handleBookingFormChange}
                      required
                    />
                  </div>
                  <div className="form-group">
                    <label htmlFor="email">Email</label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={bookingForm.email}
                      onChange={handleBookingFormChange}
                      required
                    />
                  </div>
                </div>

                <div className="form-row">
                  <div className="form-group">
                    <label htmlFor="phone">Phone Number</label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      value={bookingForm.phone}
                      onChange={handleBookingFormChange}
                      required
                    />
                  </div>
                  <div className="form-group">
                    <label htmlFor="turfType">Turf Type</label>
                    <select
                      id="turfType"
                      name="turfType"
                      value={bookingForm.turfType}
                      onChange={handleBookingFormChange}
                    >
                      {turfTypes.map(type => (
                        <option key={type.value} value={type.value}>
                          {type.label} (₹{type.price}/hour)
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="form-group">
                  <label htmlFor="date">Booking Date</label>
                  <DatePicker
                    selected={bookingForm.date}
                    onChange={handleDateChange}
                    minDate={new Date()}
                    dateFormat="dd/MM/yyyy"
                    className="date-picker"
                  />
                </div>

                <div className="form-row">
                  <div className="form-group">
                    <label htmlFor="startTime">Start Time</label>
                    <select
                      id="startTime"
                      name="startTime"
                      value={bookingForm.startTime}
                      onChange={handleBookingFormChange}
                      required
                    >
                      <option value="">Select start time</option>
                      {timeSlots.map(time => (
                        <option key={time} value={time}>{time}</option>
                      ))}
                    </select>
                  </div>
                  <div className="form-group">
                    <label htmlFor="endTime">End Time</label>
                    <select
                      id="endTime"
                      name="endTime"
                      value={bookingForm.endTime}
                      onChange={handleBookingFormChange}
                      required
                    >
                      <option value="">Select end time</option>
                      {timeSlots.map(time => (
                        <option key={time} value={time}>{time}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="form-group">
                  <label htmlFor="specialRequests">Special Requests (Optional)</label>
                  <textarea
                    id="specialRequests"
                    name="specialRequests"
                    value={bookingForm.specialRequests}
                    onChange={handleBookingFormChange}
                    rows="3"
                    placeholder="Any special requirements or notes..."
                  />
                </div>

                <div className="price-display">
                  <h3>Total Price: ₹{calculatePrice()}</h3>
                </div>

                <button type="submit" className="submit-btn">Create Booking</button>
              </form>
            </div>
          )}

          {activeTab === 'bookings' && (
            <div className="bookings-section">
              <h2>All Bookings</h2>
              <div className="bookings-list">
                {bookings.map(booking => (
                  <div key={booking.id} className="booking-card">
                    <div className="booking-header">
                      <div className="customer-info">
                        <h3>{booking.customerName}</h3>
                        <p>{booking.email} | {booking.phone}</p>
                      </div>
                      <div className="booking-status">
                        <span 
                          className="status-badge" 
                          style={{ backgroundColor: getStatusColor(booking.status) }}
                        >
                          {booking.status.toUpperCase()}
                        </span>
                      </div>
                    </div>
                    
                    <div className="booking-details">
                      <div className="detail-row">
                        <span className="label">Turf Type:</span>
                        <span className="value">{booking.turfType}</span>
                      </div>
                      <div className="detail-row">
                        <span className="label">Date:</span>
                        <span className="value">{booking.date}</span>
                      </div>
                      <div className="detail-row">
                        <span className="label">Time:</span>
                        <span className="value">{booking.startTime} - {booking.endTime}</span>
                      </div>
                      {booking.specialRequests && (
                        <div className="detail-row">
                          <span className="label">Special Requests:</span>
                          <span className="value">{booking.specialRequests}</span>
                        </div>
                      )}
                    </div>

                    <div className="booking-actions">
                      {booking.status === 'confirmed' && (
                        <button 
                          className="cancel-btn"
                          onClick={() => handleStatusUpdate(booking.id, 'cancelled')}
                        >
                          Cancel Booking
                        </button>
                      )}
                      {booking.status === 'cancelled' && (
                        <button 
                          className="confirm-btn"
                          onClick={() => handleStatusUpdate(booking.id, 'confirmed')}
                        >
                          Reactivate
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'analytics' && (
            <div className="analytics-section">
              <h2>Analytics</h2>
              <div className="stats-grid">
                <div className="stat-card">
                  <h3>Total Bookings</h3>
                  <div className="stat-number">{bookings.length}</div>
                </div>
                <div className="stat-card">
                  <h3>Today's Bookings</h3>
                  <div className="stat-number">
                    {bookings.filter(b => b.date === moment().format('YYYY-MM-DD')).length}
                  </div>
                </div>
                <div className="stat-card">
                  <h3>Confirmed Bookings</h3>
                  <div className="stat-number">
                    {bookings.filter(b => b.status === 'confirmed').length}
                  </div>
                </div>
                <div className="stat-card">
                  <h3>Cancelled Bookings</h3>
                  <div className="stat-number">
                    {bookings.filter(b => b.status === 'cancelled').length}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
